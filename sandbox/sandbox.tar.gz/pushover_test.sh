#!/bin/bash

if [ $# -eq 0 ]; then
	echo "Usage: ./pushover <message> [title]"
	exit
fi

MESSAGE=$1
TITLE=$2

if [ $# -lt 2 ]; then
	TITLE="`whoami`@${HOSTNAME}"
fi

APP_TOKEN="ar36rxo26ak7rw4w5dz7n9sce6dwsa"
USER_TOKEN="uyte9pdHen9Rnhq1vbWVH38iFikF1K"

wget https://api.pushover.net/1/messages.json --post-data="token=$APP_TOKEN&user=$USER_TOKEN&message=$MESSAGE&title=$TITLE" -qO- 2>&1


