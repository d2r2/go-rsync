package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"net/http"
	"net/http/httputil"
	"net/rpc"
	"net/rpc/jsonrpc"
	"os"
	"os/signal"
	"syscall"

	"github.com/d2r2/go-rsync/sandbox/rpc_test/spec"
)

func Log(handler http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		requestDump, err := httputil.DumpRequest(r, true)
		if err != nil {
			fmt.Println(err)
		}
		log.Println(string(requestDump))
		// log.Printf("%s %s %s", r.RemoteAddr, r.Method, r.URL)
		handler.ServeHTTP(w, r)
	})
}

func isKillPending(ctx context.Context) bool {
	select {
	case <-ctx.Done():
		return true
	default:
		return false
	}
}

// Watch for OS SIGINT or SIGKILL signals. Once it happens,
// close kill channel to broadcast message about termination
// across application.
func closeChannelOnSignal(cancel context.CancelFunc) {
	// Set up channel on which to send signal notifications
	// We must use a buffered channel or risk missing the signal
	// if we're not ready to receive when the signal
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt, os.Kill, syscall.SIGTERM)
	// run gorutine and block until a signal is received
	go func() {
		<-c
		// send signal to threads about pending to close
		// log.Warn("Signal received, close kill channel")
		cancel()
	}()
}

func main() {

	ctx := context.Background()
	ctx2, cancel := context.WithCancel(ctx)

	closeChannelOnSignal(cancel)

	arith := new(spec.Arith)

	/*
		rpc.Register(arith)
		rpc.HandleHTTP()
		l, e := net.Listen("tcp", ":1234")
		if e != nil {
			log.Fatal("listen error:", e)
		}
		http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			fmt.Fprintf(w, "Hello, %s!", r.URL.Path[1:])
		})

		http.Serve(l, Log(http.DefaultServeMux))
	*/

	server := rpc.NewServer()
	server.Register(arith)
	server.HandleHTTP(rpc.DefaultRPCPath, rpc.DefaultDebugPath)
	// listener, e := net.Listen("tcp", ":1234")
	listener, e := net.Listen("unix", "/tmp/test123456.sock")
	if e != nil {
		log.Fatal("listen error:", e)
	}
	// defer listener.Close()

	go func() {
		<-ctx2.Done()
		listener.Close()
	}()

	for {
		if conn, err := listener.Accept(); err != nil {
			if isKillPending(ctx2) {
				log.Println("termination pending...")
				os.Exit(0)
			} else {
				log.Fatal("accept error: " + err.Error())
			}
		} else {
			log.Printf("new connection established\n")
			codec := jsonrpc.NewServerCodec(conn)
			server.ServeCodec(codec)
		}
	}
}
