#!/bin/bash
sudo systemctl stop rpc_server
# sudo rm /etc/systemd/system/rpc_server.service
sudo systemctl daemon-reload
# sudo rm /usr/local/sbin/rpc_server/rpc_server

