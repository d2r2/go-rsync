#!/bin/bash
# sudo mkdir -p /usr/local/sbin/rpc_server
# sudo cp -f rpc_server /usr/local/sbin/rpc_server

# echo '
# [Unit]
# Description=Test rpc server

# [Service]
# ExecStart=/usr/local/sbin/rpc_server

# [Install]
# WantedBy=default.target
# ' > /etc/systemd/system/rpc_server.service

sudo systemctl daemon-reload
sudo systemctl restart rpc_server
