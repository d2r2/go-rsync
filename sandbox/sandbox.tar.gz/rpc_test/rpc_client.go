package main

import (
	"fmt"
	"log"
	"net"
	"net/rpc/jsonrpc"

	"github.com/d2r2/go-rsync/sandbox/rpc_test/spec"
)

func main() {
	// serverAddress := "127.0.0.1"
	// client, err := net.Dial("tcp", serverAddress+":1234")
	client, err := net.Dial("unix", "/tmp/test123456.sock")
	if err != nil {
		log.Fatal("dialing:", err)
	}
	// Synchronous call
	args := &spec.Args{7, 8}
	var reply int
	c := jsonrpc.NewClient(client)
	err = c.Call("Arith.Multiply", args, &reply)
	if err != nil {
		log.Fatal("arith error:", err)
	}
	fmt.Printf("Arith: %d*%d=%d", args.A, args.B, reply)
	fmt.Println()
}
