DESTDIR=/tmp/rpc_server
rm -R $DESTDIR

mkdir -p $DESTDIR
mkdir -p $DESTDIR/usr/local/sbin
go build -v rpc_server.go
cp ./rpc_server $DESTDIR/usr/local/sbin
mkdir -p $DESTDIR/etc/systemd/system
cp ./rpc_server.service $DESTDIR/etc/systemd/system

cp ./install_service.sh $DESTDIR
cp ./uninstall_service.sh $DESTDIR

for PKG in pacman deb rpm
do
    fpm -s dir -f -t $PKG -C $DESTDIR \
        --name rpc_server \
        --version 0.1.0 \
        --iteration 1  \
        --description "Test rpc server" \
    #    --after-install=install_service.sh \
    #    --before-remove=uninstall_service.sh \
    #    --config-files /etc
done

