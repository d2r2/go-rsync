package main

import (
	"flag"
	"log"

	"github.com/d2r2/go-rsync/io"
	"github.com/d2r2/go-rsync/sandbox/client"
)

func main() {
	flag.Parse()

	flag.Parse()
	args := flag.Args()
	if len(args) == 0 {
		log.Fatal("No arguments specified")
	}
	switch args[0] {
	case "start":
		if len(args) != 2 {
			log.Fatal("too few arguments specified")
		}
		destPath := args[1]
		config, err := io.NewConfig("./main.conf")
		if err != nil {
			log.Fatal(err)
		}
		client := client.NewClient()
		client.StartBackup(destPath, *config)
	case "stop":
		client := client.NewClient()
		client.StopBackup()
	default:
		log.Fatal("unknown command specified")
	}
}
