package ipc

type Server struct {
	ClientSocks []string
}

type EmptyReply struct {
}

type EmptyArgs struct {
}

func (this *Server) RegisterClient(clientSock string, reply *EmptyReply) error {
	reply = nil
	found := false
	for _, sock := range this.ClientSocks {
		if sock == clientSock {
			found = true
			break
		}
	}
	if !found {
		this.ClientSocks = append(this.ClientSocks, clientSock)
	}
	return nil
}

func (this *Server) UnregisterClient(clientSock string, reply *EmptyReply) error {
	reply = nil
	for i, sock := range this.ClientSocks {
		if sock == clientSock {
			this.ClientSocks = append(this.ClientSocks[:i], this.ClientSocks[i+1:]...)
			break
		}
	}
	return nil
}

type NotifyClientsArgs struct {
	ServiceMethod string
	Args          interface{}
}

func (this *Server) NotifyClients(args NotifyClientsArgs, reply *EmptyReply) error {
	for _, sock := range this.ClientSocks {
		var reply interface{}
		err := CallServer(sock, args.ServiceMethod, args.Args, &reply)
		if err != nil {
			if err == ErrorDialNetwork {
				empty := EmptyReply{}
				lg.Warn(f("unregister forcebly client \"%s\"", sock))
				this.UnregisterClient(sock, &empty)
			} else {
				lg.Error(f("Error calling \"%s\" method on client \"%s\"", args.ServiceMethod, sock))
				return err
			}
		}
	}
	return nil
}
