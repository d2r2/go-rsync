package ipc

import (
	"context"
	"errors"
	"math"
	"math/rand"
	"net"
	"net/rpc"
	"net/rpc/jsonrpc"
	"os"
	"path"
	"time"

	"github.com/d2r2/go-rsync/io"
)

var (
	sockExt        string     = "sock"
	serverSockPref string     = "gobup-server123456"
	clientSockPref string     = "gobup-client"
	rnd            *rand.Rand = rand.New(
		rand.NewSource(time.Now().UnixNano() + int64(os.Getpid())))
	ErrorDialNetwork = errors.New("dialing to send rpc request")
)

func GetServerSockName() string {
	sockName := path.Join(os.TempDir(), serverSockPref+"."+sockExt)
	return sockName
}

func GetClientSockName() string {
	maxInt := int(math.Pow10(6))
	var sockName string
	for {
		suffix := f("%06d", rnd.Intn(maxInt))
		sockName = path.Join(os.TempDir(), clientSockPref+suffix+"."+sockExt)
		if _, err := os.Stat(sockName); os.IsNotExist(err) {
			break
		}
	}
	return sockName
}

func RunServer(ctx context.Context, intfs []interface{}, serverSock string) error {

	server := rpc.NewServer()

	for _, intf := range intfs {
		server.Register(intf)
	}

	// server.HandleHTTP(rpc.DefaultRPCPath, rpc.DefaultDebugPath)
	listener, err := net.Listen("unix", serverSock)
	if err != nil {
		lg.Error("listen error:", e)
		return err
	}
	defer listener.Close()

	go func() {
		<-ctx.Done()
		listener.Close()
	}()

	for {
		lg.Info("waiting to rpc request...")
		if conn, err := listener.Accept(); err != nil {
			if io.IsKillPending(ctx) {
				lg.Info("termination pending...")
				break
			} else {
				lg.Error("accept error: " + err.Error())
			}
		} else {
			lg.Info("new connection established")
			codec := jsonrpc.NewServerCodec(conn)
			server.ServeCodec(codec)
		}
	}
	return nil
}

func CallServer(serverSock string, serviceMethod string,
	args interface{}, reply interface{}) error {
	client, err := net.Dial("unix", serverSock)
	if err != nil {
		lg.Error("dialing: ", err)
		return ErrorDialNetwork
	}
	defer client.Close()
	// Synchronous call
	c := jsonrpc.NewClient(client)
	err = c.Call(serviceMethod, args, &reply)
	if err != nil {
		lg.Error("failed to call "+serviceMethod+": ", err)
		return err
	}
	// fmt.Printf("Arith: %d*%d=%d", args.A, args.B, reply)
	// fmt.Println()
	return nil
}
