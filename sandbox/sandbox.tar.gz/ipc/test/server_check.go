package main

import (
	"context"
	"log"
	"time"

	"github.com/d2r2/go-rsync/sandbox/ipc"
	"github.com/d2r2/go-rsync/utils"
)

func isKillPending(ctx context.Context) bool {
	select {
	case <-ctx.Done():
		return true
	default:
		return false
	}
}

func main() {

	ctx := context.Background()
	ctx2, cancel := context.WithCancel(ctx)

	utils.CloseChannelOnSignal(cancel)

	server := new(ipc.Server)
	// client := new(ipc.Client)
	sock := ipc.GetServerSockName()

	strs := []interface{}{server}
	go ipc.RunServer(ctx2, strs, sock)

	for {
		msg := "Test message: Hello World !!!"
		args := ipc.NotifyClientsArgs{ServiceMethod: "Client.CallbackTest", Args: msg}
		reply := ipc.EmptyReply{}
		log.Println("Start notifying clients")
		server.NotifyClients(args, &reply)
		log.Println("End notifying clients")

		if isKillPending(ctx2) {
			break
		}

		time.Sleep(5 * time.Second)
	}

	<-ctx2.Done()

	// !!! Never delete this, because this let async jobs
	// to complete their tasks in case of pending termination.
	time.Sleep(200 * time.Millisecond)
}
