package main

import (
	"context"
	"fmt"
	"log"
	"time"

	"github.com/d2r2/go-rsync/sandbox/ipc"
	"github.com/d2r2/go-rsync/utils"
)

func isKillPending(ctx context.Context) bool {
	select {
	case <-ctx.Done():
		return true
	default:
		return false
	}
}

type Client struct {
}

type CallbackTestArgs struct {
	Message string
}

func (this *Client) CallbackTest(message string, reply *ipc.EmptyReply) error {
	log.Print(fmt.Sprintf("test rpc client call: %s", message))
	return nil
}

func main() {

	ctx := context.Background()
	ctx2, cancel := context.WithCancel(ctx)

	utils.CloseChannelOnSignal(cancel)

	// server := new(ipc.Server)
	client := new(Client)
	sock := ipc.GetClientSockName()

	strs := []interface{}{client}
	go ipc.RunServer(ctx2, strs, sock)

	serverSock := ipc.GetServerSockName()
	reply := ipc.EmptyReply{}
	log.Println("register new client on server to receive notifications")
	ipc.CallServer(serverSock, "Server.RegisterClient", sock, &reply)

	<-ctx2.Done()

	// !!! Never delete this, because this let async jobs
	// to complete their tasks in case of pending termination.
	time.Sleep(200 * time.Millisecond)
}
