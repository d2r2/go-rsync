package server

import (
	"context"
	"sync"
	"time"

	"github.com/d2r2/go-rsync/backup"
	"github.com/d2r2/go-rsync/io"
	"github.com/d2r2/go-rsync/rsync"
	"github.com/d2r2/go-rsync/sandbox/ipc"
	"github.com/davecgh/go-spew/spew"
)

type ServerState int

const (
	ST_IDLE ServerState = 1 << iota
	ST_RUN_PENDING
	ST_RUNNING
	ST_STOP_PENDING
	ST_TERMINATED
	ST_SUCESSFULLY_DONE
	ST_FAILURE

	ST_ALL = ST_IDLE | ST_RUN_PENDING | ST_RUNNING |
		ST_STOP_PENDING | ST_TERMINATED | ST_SUCESSFULLY_DONE | ST_FAILURE
)

type Server struct {
	ipc.Server

	mux             *sync.Mutex
	state           ServerState
	parent, context context.Context
	cancel          context.CancelFunc
}

func NewServer(ctx context.Context) *Server {
	srv := &Server{mux: &sync.Mutex{}, parent: ctx, state: ST_IDLE}
	return srv
}

func (this *Server) getState(mask ServerState) ServerState {
	var state ServerState = this.state & mask
	return state
}

func (this *Server) setStateWithMask(state, andMask ServerState) {
	this.state = this.state&andMask | state
}

func (this *Server) setState(state ServerState) {
	this.state = this.state&state | state
}

/*
func (this *Server) Notify1() {
	for {
		msg := "Test message: Hello World !!!"
		args := ipc.NotifyClientsArgs{ServiceMethod: "Client.CallbackTest", Args: msg}
		reply := ipc.EmptyReply{}
		log.Println("Start notifying clients")
		this.NotifyClients(args, &reply)
		log.Println("End notifying clients")

		if io.IsKillPending(ctx) {
			break
		}

		time.Sleep(5 * time.Second)
	}

}
*/

type StartBackupArgs struct {
	Config   io.Config
	DestPath string
}

func (this *Server) StartBackup(args StartBackupArgs, reply *ipc.EmptyReply) error {

	this.mux.Lock()
	defer this.mux.Unlock()

	if this.getState(ST_IDLE) != ST_IDLE {
		return e("can't run backup process, since it's not in idle state")
	}

	ctx, cancel := context.WithCancel(this.parent)
	this.cancel = cancel
	this.context = ctx

	this.setState(ST_RUN_PENDING)

	notif := &BackupNotifier{Server: this}
	go startBackup(this, ctx, &args.Config, args.DestPath, notif)

	return nil
}

func startBackup(this *Server, ctx context.Context, config *io.Config, destPath string,
	notifier backup.Notifier) error {

	this.mux.Lock()
	this.setState(ST_RUNNING)
	this.mux.Unlock()

	plan, progress, err := backup.BuildBackupPlan(ctx, nil, config, notifier)
	if err != nil {

		this.mux.Lock()
		var state ServerState = ST_IDLE
		if io.IsKillPending(this.context) {
			state |= ST_TERMINATED
		} else {
			state |= ST_FAILURE
		}
		this.setState(state)
		this.mux.Unlock()

		return err
	}

	lg.Debug(spew.Sprintf("Backup cluster's dir trees: %+v", plan))
	err = plan.RunBackup(progress, destPath)
	if err != nil {

		this.mux.Lock()
		var state ServerState = ST_IDLE
		if io.IsKillPending(this.context) {
			state |= ST_TERMINATED
		} else {
			state |= ST_FAILURE
		}
		this.setState(state)
		this.mux.Unlock()

		return err
	}

	this.mux.Lock()
	this.setState(ST_SUCESSFULLY_DONE | ST_IDLE)
	this.mux.Unlock()

	return nil

}

func (this *Server) StopBackup(args ipc.EmptyArgs, reply *ipc.EmptyReply) error {

	this.mux.Lock()
	defer this.mux.Unlock()

	var state ServerState = this.getState(ST_ALL)

	if state&ST_RUN_PENDING != 0 ||
		state&ST_RUNNING != 0 {
		this.cancel()
	} else {
		return e("can't stop server since it's in unappropriate state")
	}

	return nil

}

type BackupNotifier struct {
	Server *Server
}

type NodeStructureStartInquiryArgs struct {
	SourceID    int
	SourceRsync string
}

type NodeStructureDoneInquiryArgs struct {
	SourceID    int
	SourceRsync string
	Dir         *backup.Dir
}

type FolderStartBackupArgs struct {
	RootDest     string
	Paths        rsync.SrcDstPath
	BackupType   io.FolderBackupType
	LeftToBackup io.FolderSize
	ETA          *time.Duration
}

type FolderDoneBackupArgs struct {
	RootDest     string
	Paths        rsync.SrcDstPath
	BackupType   io.FolderBackupType
	LeftToBackup io.FolderSize
	SizeDone     io.SizeProgress
}

var _ backup.Notifier = BackupNotifier{}

func (this BackupNotifier) NotifyPlanStage_NodeStructureStartInquiry(sourceId int,
	sourceRsync string) error {

	method := "NotifyPlanStage_NodeStructureStartInquiry"
	args := ipc.NotifyClientsArgs{ServiceMethod: method,
		Args: NodeStructureStartInquiryArgs{SourceID: sourceId,
			SourceRsync: sourceRsync}}
	err := this.Server.NotifyClients(args, &ipc.EmptyReply{})
	if err != nil {
		return err
	}

	return nil
}

func (this BackupNotifier) NotifyPlanStage_NodeStructureDoneInquiry(sourceId int,
	sourceRsync string, dir *backup.Dir) error {

	method := "NotifyPlanStage_NodeStructureDoneInquiry"
	args := ipc.NotifyClientsArgs{ServiceMethod: method,
		Args: NodeStructureDoneInquiryArgs{SourceID: sourceId,
			SourceRsync: sourceRsync,
			Dir:         dir}}
	err := this.Server.NotifyClients(args, &ipc.EmptyReply{})
	if err != nil {
		return err
	}
	return nil
}

func (this BackupNotifier) NotifyBackupStage_FolderStartBackup(rootDest string,
	paths rsync.SrcDstPath, backupType io.FolderBackupType,
	leftToBackup io.FolderSize, timePassed time.Duration, eta *time.Duration) error {

	method := "NotifyBackupStage_FolderStartBackup"
	args := ipc.NotifyClientsArgs{ServiceMethod: method,
		Args: FolderStartBackupArgs{RootDest: rootDest, Paths: paths,
			LeftToBackup: leftToBackup, ETA: eta, BackupType: backupType}}
	err := this.Server.NotifyClients(args, &ipc.EmptyReply{})
	if err != nil {
		return err
	}

	return nil
}

func (this BackupNotifier) NotifyBackupStage_FolderDoneBackup(rootDest string,
	paths rsync.SrcDstPath, backupType io.FolderBackupType, leftToBackup io.FolderSize,
	sizeDone io.SizeProgress, timePassed time.Duration, eta *time.Duration,
	error *rsync.ErrorSpec) error {

	method := "NotifyBackupStage_FolderDoneBackup"
	args := ipc.NotifyClientsArgs{ServiceMethod: method,
		Args: FolderDoneBackupArgs{RootDest: rootDest, Paths: paths,
			LeftToBackup: leftToBackup, BackupType: backupType,
			SizeDone: sizeDone}}
	err := this.Server.NotifyClients(args, &ipc.EmptyReply{})
	if err != nil {
		return err
	}

	return nil
}
