import gi
gi.require_version('Gtk', '3.0')

from gi.repository import Gtk
from gi.repository import Gio
import sys



class MyApplication(Gtk.Application):


    # callback function for "new"
    def new_cb(self, action, parameter):
        print("This does nothing. It is only a demonstration.")

    # callback function for "about"
    def about_cb(self, action, parameter):
        print("No AboutDialog for you. This is only a demonstration.")

    # callback function for "quit"
    def quit_cb(self, action, parameter):
        print("You have quit.")
        self.quit()

    def on_click(button):
        #Toggl
        if popover.get_visible():
            popover.hide()
        else:
            popover.show_all()


app = MyApplication()

#Creating the window
window = Gtk.Window(title="Hello Popover")
window.connect("destroy", lambda w: Gtk.main_quit())

# create a menu
menu = Gio.Menu()
# append to the menu three options
menu.append("New", "app.new")
menu.append("About", "app.about")
menu.append("Quit", "app.quit")
# set the menu as menu of the application
# app.set_app_menu(menu)

# create an action for the option "new" of the menu
new_action = Gio.SimpleAction.new("new", None)
# connect it to the callback function new_cb
new_action.connect("activate", app.new_cb)
# add the action to the application
app.add_action(new_action)

# option "about"
about_action = Gio.SimpleAction.new("about", None)
about_action.connect("activate", app.about_cb)
app.add_action(about_action)

# option "quit"
quit_action = Gio.SimpleAction.new("quit", None)
quit_action.connect("activate", app.quit_cb)
app.add_action(quit_action)


#Creating and placing a button.
box = Gtk.Box(spacing = 60)
button = Gtk.Button("Toggle popover")
# button.connect("clicked", app.on_click)
box.add(button)
window.add(box)

#Creating a popover
popover = Gtk.Popover.new(button)
popover.set_size_request(50,100)
# label = Gtk.Label("Hi!")
# label = Gtk.CheckButton("sdfsdf")
# popover.add(label)
# menu = GtkMenu.new(popover)

# mi = Gtk.MenuItem("dfdfdf", "app.about")
# popover.add(menu)
popover.bind_model(menu)
popover.set_relative_to(button)


window.set_size_request(200,200)
window.show_all()



Gtk.main()


