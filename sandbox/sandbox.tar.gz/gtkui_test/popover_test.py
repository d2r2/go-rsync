import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk

def on_click(button):
    #Toggl
    if popover.get_visible():
        popover.hide()
    else:
        popover.show_all()

#Creating the window
window = Gtk.Window(title="Hello Popover")
window.connect("destroy", lambda w: Gtk.main_quit())

#Creating and placing a button.
box = Gtk.Box(spacing = 60)
button = Gtk.Button("Toggle popover")
button.connect("clicked", on_click)
box.add(button)
window.add(box)

#Creating a popover
popover = Gtk.Popover.new(button)
popover.set_size_request(50,100)
# label = Gtk.Label("Hi!")
# label = Gtk.CheckButton("sdfsdf")
# popover.add(label)
menu = GtkMenu.new(popover)

mi = Gtk.MenuItem("dfdfdf")
popover.add(menu)


window.set_size_request(200,200)
window.show_all()

Gtk.main()

