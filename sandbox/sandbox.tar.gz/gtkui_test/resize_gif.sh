#!/bin/bash
# convert $1 -colorspace Gray -filter hermite -coalesce -scale $2 $(basename $1 .gif)_$2.gif
convert $1 -colorspace Gray -coalesce -resize $2 $(basename $1 .gif)_$2.gif
# convert $1 -colorspace Gray -coalesce -bordercolor LightSteelBlue -border 0 -resize $2 -layers Optimize $(basename $1 .gif)_$2.gif


