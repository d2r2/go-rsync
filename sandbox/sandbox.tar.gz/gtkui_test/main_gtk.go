package main

import (
	"errors"
	"io/ioutil"
	"log"
	"strings"

	"github.com/d2r2/gotk3/glib"
	"github.com/d2r2/gotk3/gtk"
	"github.com/davecgh/go-spew/spew"
)

type GUI_Data struct {
	EventBox             *gtk.EventBox
	Revealer             *gtk.Revealer
	FullscreeAction      *glib.Action
	RightTopMenuButton   *gtk.MenuButton
	InFullscreenEventBox bool
}

func setupHeader(title string, showCloseButton bool) (*gtk.HeaderBar, error) {
	hdr, err := gtk.HeaderBarNew()
	if err != nil {
		return nil, err
	}
	hdr.SetShowCloseButton(showCloseButton)
	hdr.SetProperty("title", title)
	return hdr, nil
}

func setupApplicationWindow(app *gtk.Application, title string) (*gtk.ApplicationWindow, error) {
	win, err := gtk.ApplicationWindowNew(app)
	if err != nil {
		return nil, err
	}
	win.SetTitle(title)
	win.Connect("destroy", func() {
		gtk.MainQuit()
	})
	win.SetDefaultSize(800, 600)
	win.SetPosition(gtk.WIN_POS_CENTER)
	return win, nil
}

func setupBox(orient gtk.Orientation) (*gtk.Box, error) {
	box, err := gtk.BoxNew(orient, 0)
	if err != nil {
		return nil, err
	}
	return box, nil
}

func setupTview() (*gtk.TextView, error) {
	tv, err := gtk.TextViewNew()
	if err != nil {
		return nil, err
	}
	return tv, nil
}

func setupBtn(label string, onClick func()) (*gtk.Button, error) {
	btn, err := gtk.ButtonNewWithLabel(label)
	if err != nil {
		return nil, err
	}
	btn.Connect("clicked", onClick)
	return btn, nil
}

func setupPupover(relative gtk.IWidget) (*gtk.Popover, error) {

	menu, err := gtk.PopoverNew(relative)
	if err != nil {
		return nil, err
	}

	menu.ShowAll()

	return menu, nil

}

func createMenuModel() (*glib.MenuModel, error) {
	// menuRootItem1, err := gtk.MenuItemNewWithLabel("dfdfdfdf")
	// if err != nil {
	// 	return
	// }

	// menuSubItem1, err := gtk.MenuNew()
	// if err != nil {
	// 	return
	// }
	// menuRootItem1.SetSubmenu(menuSubItem1)

	me, err := glib.MenuNew()
	if err != nil {
		return nil, err
	}

	val1, err := glib.VariantStringNew("horizontal-buttons")
	if err != nil {
		return nil, err
	}
	val2, err := glib.VariantStringNew("go-next-symbolic")
	if err != nil {
		return nil, err
	}
	ic, err := glib.ThemedIconNew("go-next-symbolic")
	if err != nil {
		return nil, err
	}

	var meSection *glib.Menu
	var label, detAction string

	meSection, err = glib.MenuNew()
	if err != nil {
		return nil, err
	}
	// me.AppendSection(nil, &meSection.MenuModel)
	label = "option 1"
	detAction = "win.BBB"
	mi1, err := glib.MenuItemNew(label, detAction)
	if err != nil {
		return nil, err
	}
	mi1.SetAttributeValue("verb-icon", val2)
	mi1.SetIcon(&ic.Icon)

	meSection.AppendItem(mi1)
	label = "option 2"
	detAction = "win.BBB"
	mi1, err = glib.MenuItemNew(label, detAction)
	if err != nil {
		return nil, err
	}
	mi1.SetAttributeValue("verb-icon", val2)
	mi1.SetIcon(&ic.Icon)
	meSection.AppendItem(mi1)
	label = ""
	mi1, err = glib.MenuItemNew("", "")
	if err != nil {
		return nil, err
	}
	mi1.SetSection(&meSection.MenuModel)
	mi1.SetAttributeValue("display-hint", val1)
	me.AppendItem(mi1)

	meSection, err = glib.MenuNew()
	if err != nil {
		return nil, err
	}
	me.AppendSection("", &meSection.MenuModel)
	label = "Fullscreen mode"
	detAction = "win.FullscreenAction"
	meSection.Append(label, detAction)

	meSection, err = glib.MenuNew()
	if err != nil {
		return nil, err
	}
	me.AppendSection("", &meSection.MenuModel)
	label = "Enable/Disable"
	detAction = "win.CheckBoxAction"
	meSection.Append(label, detAction)
	label = "option 5"
	detAction = "win.BBB"
	meSection.Append(label, detAction)

	meSection, err = glib.MenuNew()
	if err != nil {
		return nil, err
	}
	me.AppendSection("", &meSection.MenuModel)
	label = "Red"
	detAction = "win.ChooseColor('red')"
	meSection.Append(label, detAction)
	label = "Green"
	detAction = "win.ChooseColor('green')"
	meSection.Append(label, detAction)
	label = "Blue"
	detAction = "win.ChooseColor('blue')"
	meSection.Append(label, detAction)

	meSection, err = glib.MenuNew()
	if err != nil {
		return nil, err
	}
	me.AppendSection("", &meSection.MenuModel)
	me2, err := glib.MenuNew()
	if err != nil {
		return nil, err
	}
	label = "Fullscreen mode"
	detAction = "win.FullscreenAction"
	me2.Append(label, detAction)
	subMenu := "Submenu"
	meSection.AppendSubmenu(subMenu, &me2.MenuModel)

	//namespace := "win"
	//mi1.SetActionAndTargetValue("AAA", nil)

	return &me.MenuModel, nil
}

func createMenuModel2() (*glib.MenuModel, error) {

	me, err := glib.MenuNew()
	if err != nil {
		return nil, err
	}

	subMenu := "Menu 1"
	me1, err := glib.MenuNew()
	if err != nil {
		return nil, err
	}
	me.AppendSubmenu(subMenu, &me1.MenuModel)

	val1, err := glib.VariantStringNew("horizontal-buttons")
	if err != nil {
		return nil, err
	}
	val2, err := glib.VariantStringNew("edit-cut-symbolic")
	if err != nil {
		return nil, err
	}
	meSection := glib.MenuNew()
	me1.AppendSection(nil, &meSection.MenuModel)
	label := "option 1"
	detAction := "win.AA"
	mi1 := glib.MenuItemNew(&label, &detAction)
	mi1.SetAttributeValue("verb-icon", val2)
	meSection.AppendItem(mi1)
	label = "option 2"
	detAction = "win.AA"
	mi1 = glib.MenuItemNew(&label, &detAction)
	mi1.SetAttributeValue("verb-icon", val2)
	meSection.AppendItem(mi1)
	mi1 = glib.MenuItemNew(nil, nil)
	mi1.SetSection(&meSection.MenuModel)
	mi1.SetAttributeValue("display-hint", val1)

	meSection = glib.MenuNew()
	me1.AppendSection(nil, &meSection.MenuModel)
	label = "Fullscreen mode"
	detAction = "win.FullscreenAction"
	meSection.Append(&label, &detAction)

	meSection = glib.MenuNew()
	me1.AppendSection(nil, &meSection.MenuModel)
	label = "Red"
	detAction = "win.ChooseColor('red')"
	meSection.Append(&label, &detAction)
	label = "Green"
	detAction = "win.ChooseColor('green')"
	meSection.Append(&label, &detAction)
	label = "Blue"
	detAction = "win.ChooseColor('blue')"
	meSection.Append(&label, &detAction)

	meSection = glib.MenuNew()
	me1.AppendSection(nil, &meSection.MenuModel)
	me2 := glib.MenuNew()
	label = "Fullscreen"
	detAction = "win.FullscreenAction"
	me2.Append(&label, &detAction)
	subMenu = "Submenu"
	meSection.AppendSubmenu(&subMenu, &me2.MenuModel)

	//namespace := "win"
	//mi1.SetActionAndTargetValue("AAA", nil)

	return &me.MenuModel, nil
}

func createPopover(wgt gtk.IWidget) (*gtk.Popover, error) {
	menu, err := setupPupover(wgt)
	if err != nil {
		return nil, err
	}

	return menu, nil
}

func createMenuButton() (*gtk.MenuButton, error) {
	img, err := gtk.ImageNew()
	if err != nil {
		return nil, err
	}
	img.SetFromIconName("mail-send-receive-symbolic", gtk.ICON_SIZE_BUTTON)

	btn, err := gtk.MenuButtonNew()
	if err != nil {
		return nil, err
	}

	btn.Add(img)

	return btn, nil
}

func createHeader(btn *gtk.MenuButton, showCloseButton bool) (*gtk.HeaderBar, error) {

	hdr, err := setupHeader("Test app", showCloseButton)
	if err != nil {
		return nil, err
	}

	hdr.PackEnd(btn)

	return hdr, nil
}

func createMenuBar2(menu *glib.MenuModel) (*gtk.MenuBar, error) {
	menuBar, err := gtk.MenuBarFromModelNew(menu)
	if err != nil {
		return nil, err
	}

	return menuBar, nil
}

func createMenuBar(wim *gtk.ApplicationWindow) (*gtk.MenuBar, error) {
	menuBar, err := gtk.MenuBarNew()
	if err != nil {
		return nil, err
	}

	menuRootItem1, err := gtk.MenuItemNewWithLabel("dfdfdfdf")
	if err != nil {
		return nil, err
	}

	menuSubItem1, err := gtk.MenuNew()
	if err != nil {
		return nil, err
	}
	menuRootItem1.SetSubmenu(menuSubItem1)

	menuItem11, err := gtk.MenuItemNewWithLabel("1111")
	if err != nil {
		return nil, err
	}
	menuSubItem1.Add(menuItem11)

	menuItem11.Connect("activate", func() {
		log.Println("menuItem1 clicked")
		act1 := wim.LookupAction("AAA")
		act1.Activate(nil)
	})

	menuItem12, err := gtk.CheckMenuItemNewWithLabel("sdfsdfsdf")
	if err != nil {
		return nil, err
	}
	menuSubItem1.Add(menuItem12)

	menuBar.Add(menuRootItem1)
	menuBar.ShowAll()

	return menuBar, nil
}

func creatToolbar() (*gtk.Toolbar, error) {
	tbx, err := gtk.ToolbarNew()
	if err != nil {
		return nil, err
	}

	files, err := ioutil.ReadDir("./")
	if err != nil {
		return nil, err
	}

	for _, f := range files {
		if strings.HasSuffix(f.Name(), "32x32.gif") {
			img, err := gtk.ImageNewFromFile(f.Name())
			if err != nil {
				return nil, err
			}
			titem, err := gtk.ToolButtonNew(img, "")
			if err != nil {
				return nil, err
			}
			tbx.Add(titem)
		}
	}
	return tbx, nil
}

func createCheckBoxAction() (*glib.Action, error) {
	v, err := glib.VariantBooleanNew(true)
	if err != nil {
		return nil, err
	}
	act, err := glib.SimpleActionStatefullNew("CheckBoxAction", nil, v)
	if err != nil {
		log.Fatal(err)
	}
	if act == nil {
		log.Fatal(errors.New("error"))
	}

	act.Connect("activate", func(obj *glib.Object, newVal *glib.Variant) {
		propName, err := obj.GetProperty("name")
		if err != nil {
			return
		}
		log.Println(spew.Sprintf("%v action activated with current state %v and args %v",
			propName, v, newVal))

		v, err := act.GetState()
		if err != nil {
			return
		}
		if v.IsType(glib.VARIANT_TYPE_BOOLEAN) {
			v, err = glib.VariantBooleanNew(!v.GetBoolean())
			if err != nil {
				return
			}
			act.ChangeState(v)
		}
	})

	return &act.Action, nil
}

func createChooseAction() (*glib.Action, error) {
	v, err := glib.VariantStringNew("green")
	if err != nil {
		return nil, err
	}
	act, err := glib.SimpleActionStatefullNew("ChooseColor", glib.VARIANT_TYPE_STRING, v)
	if err != nil {
		log.Fatal(err)
	}
	if act == nil {
		log.Fatal(errors.New("error"))
	}

	act.Connect("activate", func(_ *glib.Object, newVal *glib.Variant) {
		log.Println(spew.Sprintf("action activate args: %+v", newVal.String()))
		v, err := act.GetState()
		if err != nil {
			log.Println("error")
			return
		}
		log.Println(spew.Sprintf("action current state: %v", v))

		act.ChangeState(newVal)
	})

	return &act.Action, nil
}

func createFullscreenAction(win *gtk.Window, data *GUI_Data) (*glib.Action, error) {
	v, err := glib.VariantBooleanNew(false)
	if err != nil {
		return nil, err
	}
	act, err := glib.SimpleActionStatefullNew("FullscreenAction", nil, v)
	if err != nil {
		log.Fatal(err)
	}
	data.FullscreeAction = &act.Action

	act.Connect("activate", func(_ *glib.Object, newVal *glib.Variant) {
		log.Println(spew.Sprintf("action activate args: %+v", newVal.String()))
		log.Println(spew.Sprintf("action current state: %v", v))

		v, err := act.GetState()
		if err != nil {
			return
		}
		if v.IsType(glib.VARIANT_TYPE_BOOLEAN) {
			v, err = glib.VariantBooleanNew(!v.GetBoolean())
			if err != nil {
				return
			}
			act.ChangeState(v)

			if v.GetBoolean() {
				win.Fullscreen()

				data.EventBox.ShowAll()
				data.Revealer.SetRevealChild(false)

			} else {

				data.EventBox.Hide()
				data.Revealer.SetRevealChild(false)
				win.Unfullscreen()

			}
		}
	})

	return &act.Action, nil
}

func createRevealer(data *GUI_Data) (*gtk.Revealer, error) {
	rev, err := gtk.RevealerNew()
	if err != nil {
		return nil, err
	}
	box, err := setupBox(gtk.ORIENTATION_VERTICAL)
	if err != nil {
		return nil, err
	}
	rev.Add(box)

	menu, err := createMenuModel()
	if err != nil {
		log.Fatal(err)
	}

	btn, err := createMenuButton()
	if err != nil {
		log.Fatal(err)
	}
	data.RightTopMenuButton = btn

	btn.SetUsePopover(true)
	btn.SetMenuModel(menu)

	hdr, err := createHeader(btn, false)
	if err != nil {
		log.Fatal(err)
	}

	box.PackStart(hdr, false, false, 0)

	return rev, nil

}

func setupEventBox() (*gtk.EventBox, error) {
	eb, err := gtk.EventBoxNew()
	if err != nil {
		return nil, err
	}

	return eb, nil
}

func createEventBox(data *GUI_Data) (*gtk.EventBox, error) {
	eb, err := setupEventBox()
	if err != nil {
		return nil, err
	}
	eb.Connect("enter-notify-event", func() {
		log.Println("EventBox enter notify")

		data.InFullscreenEventBox = true

		v, err := data.FullscreeAction.GetState()
		if err != nil {
			log.Println("error")
			return
		}
		if v.GetBoolean() {
			data.Revealer.SetRevealChild(true)
		}
	})
	eb.Connect("leave-notify-event", func() {
		glib.IdleAdd(func() {
			log.Println("EventBox leave notify")

			data.InFullscreenEventBox = true
			v, err := data.FullscreeAction.GetState()
			if err != nil {
				log.Println("error")
				return
			}
			if v.GetBoolean() && !data.RightTopMenuButton.GetActive() {
				data.Revealer.SetRevealChild(false)
			}
		})
	})

	return eb, nil
}

func main() {

	data := &GUI_Data{}

	gtk.Init(nil)
	app, err := gtk.ApplicationNew("org.gtk1.test", glib.APPLICATION_FLAGS_NONE)
	if err != nil {
		log.Fatal(err)
	}

	app.Application.Connect("activate", func() {
		win, err := setupApplicationWindow(app, "Example")
		if err != nil {
			log.Fatal(err)
		}

		//app.AddWindow(&win.Window)

		win.Connect("destroy", func() {
			gtk.MainQuit()
		})

		act, err := createCheckBoxAction()
		if err != nil {
			log.Fatal(err)
		}
		win.AddAction(act)

		act, err = createChooseAction()
		if err != nil {
			log.Fatal(err)
		}
		win.AddAction(act)

		act1, err := glib.SimpleActionNew("BBB", nil)
		if err != nil {
			log.Fatal(err)
		}
		if act1 == nil {
			log.Fatal(errors.New("error"))
		}

		act1.Connect("activate", func(_ *glib.Object, value *glib.Variant) {
			log.Println(spew.Sprintf("action args: %+v", value.String()))
			_, err := act1.GetState()
			if err != nil {
				log.Println("error")
				return
			}

			log.Println("BBB action is activated")
		})
		win.AddAction(act)

		menu, err := createMenuModel()
		if err != nil {
			log.Fatal(err)
		}

		btn, err := createMenuButton()
		if err != nil {
			log.Fatal(err)
		}

		btn.SetUsePopover(true)
		btn.SetMenuModel(menu)

		hdr, err := createHeader(btn, true)
		if err != nil {
			log.Fatal(err)
		}

		win.SetTitlebar(hdr)

		//bindModel(po)

		box, err := setupBox(gtk.ORIENTATION_VERTICAL)
		if err != nil {
			log.Fatal(err)
		}

		eb, err := createEventBox(data)
		if err != nil {
			log.Fatal(err)
		}
		data.EventBox = eb
		rev, err := createRevealer(data)
		if err != nil {
			log.Fatal(err)
		}
		data.Revealer = rev
		eb.Add(rev)
		eb.SetSizeRequest(-1, 1)
		eb.Hide()

		box.PackStart(eb, false, false, 0)

		menu2, err := createMenuModel2()
		if err != nil {
			log.Fatal(err)
		}

		menuBar, err := createMenuBar2(menu2)
		if err != nil {
			log.Fatal(err)
		}

		box.PackStart(menuBar, false, false, 0)

		tbx, err := creatToolbar()
		if err != nil {
			log.Fatal(err)
		}

		box.PackStart(tbx, false, false, 0)

		div, err := gtk.SeparatorNew(gtk.ORIENTATION_HORIZONTAL)
		if err != nil {
			log.Fatal(err)
		}
		box.PackStart(div, false, false, 0)

		win.Add(box)

		act, err = createFullscreenAction(&win.Window, data)
		if err != nil {
			log.Fatal(err)
		}
		win.AddAction(act)

		win.ShowAll()

	})

	// thm, err := gtk.IconThemeGetDefault()
	// if err != nil {
	// 	log.Fatal(err)
	// }
	// pbf, err := thm.LoadIcon("mail-send-receive-symbolic", gtk.ICON_SIZE_BUTTON, 0)
	// if err != nil {
	// 	log.Fatal(err)
	// }

	// Use objcopy utility and debug/elf to embedd and read resources from executable file

	// img, err := gtk.ImageNewFromFile("./ajax-loader-gears_32x32.gif")
	// img, err := gtk.ImageNewFromFile("./dotdot32x32.gif")

	app.Run([]string{})
	app.Application.Unref()
	//gtk.Main()
}
