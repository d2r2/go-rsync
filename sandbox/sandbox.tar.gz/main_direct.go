package main

import (
	"context"
	"flag"
	"fmt"
	"os"

	"github.com/d2r2/go-logger"
	"github.com/d2r2/go-rsync/backup"
	"github.com/d2r2/go-rsync/io"
	"github.com/d2r2/go-shell"
	"github.com/davecgh/go-spew/spew"
)

var lg = logger.NewPackageLogger("main",
	// logger.DebugLevel,
	logger.InfoLevel,
)

var e = fmt.Errorf
var f = fmt.Sprintf

func main() {
	format := logger.FormatOptions{PackageLength: 6}
	logger.SetFormatOptions(format)
	// logger.SetPackagePrintLength(6)
	logger.SetLogFileName("./main_direct")
	logger.SetRotateParams(1024*1024*512, 2)
	logger.EnableSyslog(true)
	defer logger.FinalizeLogger()

	config, err := io.NewConfig("./main.conf")
	if err != nil {
		lg.Error(err)

		os.Exit(1)
	}
	flag.Parse()
	args := flag.Args()
	if len(args) == 0 {
		lg.Errorf("No destination path specified as parameter")
		os.Exit(1)
	}
	done := make(chan struct{})
	defer close(done)
	// Create context with cancellation possibility.
	ctx, cancel := context.WithCancel(context.Background())
	shell.CloseContextOnKillSignal(cancel, done)
	destPath := args[0]

	plan, progress, err := backup.BuildBackupPlan(ctx, nil, config, nil)
	if err != nil {
		lg.Error(err)
		os.Exit(1)
	}

	lg.Debug(spew.Sprintf("Backup cluster's dir trees: %+v", plan))
	err = plan.RunBackup(progress, destPath)
	if err != nil {
		lg.Error(err)
		os.Exit(1)
	}

}
