package client

import (
	"log"

	"github.com/d2r2/go-rsync/io"
	"github.com/d2r2/go-rsync/sandbox/ipc"
	"github.com/d2r2/go-rsync/sandbox/server"
)

type Client struct {
}

func NewClient() *Client {
	client := &Client{}
	return client
}

func (this *Client) StartBackup(destPath string, config io.Config) error {

	serverSock := ipc.GetServerSockName()
	reply := ipc.EmptyReply{}
	log.Println("Server start to backup pending")
	args := &server.StartBackupArgs{DestPath: destPath, Config: config}
	err := ipc.CallServer(serverSock, "Server.StartBackup", args, &reply)
	if err != nil {
		return err
	}

	return nil
}

func (this *Client) StopBackup() error {

	serverSock := ipc.GetServerSockName()
	reply := ipc.EmptyReply{}
	log.Println("Server stop to backup pending")
	args := ipc.EmptyArgs{}
	err := ipc.CallServer(serverSock, "Server.StopBackup", args, &reply)
	if err != nil {
		return err
	}

	return nil
}
