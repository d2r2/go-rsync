package main

import (
	"context"
	"time"

	"github.com/d2r2/go-rsync/sandbox/ipc"
	"github.com/d2r2/go-rsync/sandbox/server"
	"github.com/d2r2/go-shell"
)

func main() {

	done := make(chan struct{})
	defer close(done)
	// Create context with cancellation possibility.
	ctx, cancel := context.WithCancel(context.Background())
	shell.CloseContextOnKillSignal(cancel, done)

	srv := server.NewServer(ctx)
	// client := new(ipc.Client)
	sock := ipc.GetServerSockName()

	intrfs := []interface{}{srv}
	go ipc.RunServer(ctx, intrfs, sock)

	<-ctx.Done()

	// !!! Never delete this, because this let async jobs
	// to complete their tasks in case of pending termination.
	time.Sleep(200 * time.Millisecond)
}
